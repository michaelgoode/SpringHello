package com.springapp.dao;

import com.springapp.model.AssociationBatch;


import java.util.List;

/**
 * Created by michaelgoode on 08/09/2016.
 */
public interface AssociationBatchDAO {
    public List<AssociationBatch> listBatch();
}
