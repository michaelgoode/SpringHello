package com.springapp.com.springapp.config;

import javax.sql.DataSource;

import com.springapp.dao.*;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages="com.springapp")
@EnableWebMvc
public class MvcConfiguration extends WebMvcConfigurerAdapter{

    @Bean
    public ViewResolver getViewResolver(){
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/WEB-INF/pages/");
        resolver.setSuffix(".jsp");
        return resolver;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
    }

    @Bean
    public DataSource getDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("net.sourceforge.jtds.jdbcx.JtdsDataSource");
        dataSource.setUrl("jdbc:jtds:sqlserver://192.168.2.9/MS_Production");
        dataSource.setUsername("mike");
        dataSource.setPassword("Pass123");
        return dataSource;
    }

    @Bean
    public HeaderDAO getHeaderDAO() {
        return new HeaderDAOImpl(getDataSource());
    }

    @Bean
    public EPCDAO getEPCDAO() {
        return new EPCDAOImpl(getDataSource());
    }

    @Bean
    public ContractDAO getContractDAO() {
        return new ContractDAOImpl(getDataSource());
    }

    @Bean
    public AssociationBatchDAO getAssociationBatchDAO() {
        return new AssociationBatchDAOImpl(getDataSource());
    }

    @Bean
    public UnassociatedReportDAO getUnassociatedReportDAO() { return new UnassociatedReportDAOImpl(getDataSource()); }

}
