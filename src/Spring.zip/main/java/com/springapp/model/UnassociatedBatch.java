package com.springapp.model;

import java.sql.Date;

/**
 * Created by michaelgoode on 20/09/2016.
 */
public class UnassociatedBatch {

    private String filename;
    private Date dateTime;
    private String epc;
    private boolean isValid;

}
