package com.springapp.model;

/**
 * Created by michaelgoode on 23/09/2015.
 */
public class Product {
    private String callout;
    private String product;

    public String getCallout() {
        return callout;
    }
    public void setCallout(String callout) {
        this.callout = callout;
    }
}
